<?php include_once "header.php"; ?>
Welcome to Wisemoney.

<?php include_once "footer.php"; ?>