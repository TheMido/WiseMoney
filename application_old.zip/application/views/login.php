<?php
include_once ('header.php'); ?>

<!-- Page Header -->
<div class="container">
        <div class="row">
            <div class="col-lg-12">
                <h1  style="text-align:center; color: #222121; font-family:Tale ; color:#3c8dbc;" >Login</h1>
            </div>
        </div>
        <!-- /.row -->

        <!-- Projects Row -->
        <div class="row">
            <div class="col-md-6 portfolio-item">
                <h3 style="text-align:center">
                    As a User
                </h3>
                <div class="box box-primary" style="width:100%">
                    
                    <!-- form start -->
                    <!--<form role="form" action="" method="post">-->
                    <?php //echo validation_errors(); ?>
                    <form action="" method="post">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email" name="email"/>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password" name="password"/>
                            </div>
                           
                            <div class="checkbox">
                                <label>
                                    <input type="checkbox"/> Remember Me!
                                </label>
  								<input type="submit" class="btn btn-success" value="Login" style="background-color:#2ecc71; color:white;margin-left:10px; margin-right:10px;"/>Login
								<!--<a class="btn" href="#" style=" background-color:#2ecc71; color:white;margin-left:10px; margin-right:10px;">Login</a>-->
                                <a class="btn" href="usersignup.php" style="float:right; background-color:#1774aa; color:white;">Sign Up</a>
                                

                            </div>
                        </div><!-- /.box-body -->
                       
                    </form>
                </div><!-- /.box -->
               </div>
          
            
    <div class="col-md-6 portfolio-item">
                <h3 style="text-align:center">
                    As a Place
                </h3>
                <div class="box box-primary" style="border-top-color: #2ecc71">

                    <!-- form start -->
                    <form role="form">
                        <div class="box-body">
                            <div class="form-group">
                                <label for="exampleInputEmail1">Email address</label>
                                <input type="email" class="form-control" id="exampleInputEmail1" placeholder="Enter email"/>
                            </div>
                            <div class="form-group">
                                <label for="exampleInputPassword1">Password</label>
                                <input type="password" class="form-control" id="exampleInputPassword1" placeholder="Password"/>
                            </div>

                            <div class="checkbox">
                                <label>
                                    <input type="checkbox" id="rememberMe"/> Remember Me!
                                </label> 
                                <input class="btn btn-success" type="submit" value="Login" style=" background-color:#2ecc71; color:white;margin-left:10px; margin-right:10px;" />
                                <a class="btn" href="Place SignUp.html" style="float:right; background-color:#1774aa; color:white;">Sign Up</a>

                            </div>
                        </div><!-- /.box-body -->
                       
                    </form>
                </div><!-- /.box -->
               

        </div>
             <h1 style=" font-family:Tale; text-align:center; padding:0px; margin:0px; color: #3c8dbc">
                About Us
            </h1>
             <div class="box box-primary" style="width:100%">
                    
                    
                        <p style="text-align:center; text-shadow:2px ; font-family:helvetica, ; padding: 10px;">
                            This application aims to be an easy to use intelligent system that helps the user manage his financial resources, by analyzing income and payments. Being accessible through different platforms (web-based, mobile and tablets). With wide range of features (different analytics, easy to use system being concerned with User Experience principles and Smooth GUI).
                            Creating a Win-Win situation to both users and Places. Providing users with Wallet Friendly offers from places (and special ones for app users), and providing places with useful users’ Database which can offer lots of useful information.

                   
                   
                        </p>
                </div>
  </div>
<?php include_once ('footer.php'); ?>