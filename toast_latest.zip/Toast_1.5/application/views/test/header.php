<html>
<head>
<title>Unit test results</title>
<style type="text/css">
* { font-family: Arial, sans-serif; font-size: 9pt }
#results { width: 100% }
.err, .pas { color: white; font-weight: bold; margin: 2px 0; padding: 5px; vertical-align: top; }
.err { background-color: red }
.pas { background-color: green }
.detail { padding: 8px 0 8px 20px }
h1 { font-size: 12pt }
a:link, a:visited { text-decoration: none; color: white }
a:active, a:hover { text-decoration: none; color: black; background-color: yellow }
</style>
</head>
<body>

<h1>Toast Unit Tests:</h1>

<ol>
