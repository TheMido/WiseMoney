</div>
       
        <p style="text-align:center; margin-top:18px; margin-bottom:15px;">Copyright &copy; MMW</p>      
    </div>
    <!-- /.container -->

    
<!-- jQuery -->
    <script src="<?=base_url().'assets/js/jquery.js'?>"></script>
    <script src="<?=base_url().'assets/js/custom.js'?>"></script>

    <!-- Bootstrap Core JavaScript -->
    <script src="<?=base_url().'assets/js/bootstrap.min.js'?>"></script>


</body>

</html>