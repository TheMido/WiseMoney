<?php

/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

include_once "header.php";
?>


<div style="font-size:20px;color:red;">
    <p>Wrong details!</p>
</div>
<?php
include_once "footer.php";
?>
